"""
Package for the application.
"""
